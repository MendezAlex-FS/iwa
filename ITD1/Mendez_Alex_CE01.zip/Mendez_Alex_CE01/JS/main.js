document.addEventListener("DOMContentLoaded", function () {
  // Alert shows the correct phrase and works correctly.
  alert("My JavaScript file is connected properly!");

  // Console shows the correct phrase and works correctly.
  console.log("I can display text in the Console!");
});
